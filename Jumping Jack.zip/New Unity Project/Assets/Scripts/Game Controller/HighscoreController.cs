﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HighscoreController : MonoBehaviour {

    [SerializeField]
    private Text scoreText, coinText;


	// Use this for initialization
	void Start () {

        SetScoreBasedOnDifficulty();

	}

    void SetScore(int score, int coinScore)
    {
        scoreText.text = score.ToString();
        coinText.text = coinScore.ToString();
    }

    void SetScoreBasedOnDifficulty()
    {
        //easy
        if(GamePrefrences.GetEasyDifficultyState() == 1)
        {
            SetScore(GamePrefrences.GetEasyDifficultyHighscore(), GamePrefrences.GetEasyDifficultyCoinScore());
        }

        //medium
        if (GamePrefrences.GetMediumDifficultyState() == 1)
        {
            SetScore(GamePrefrences.GetMediumDifficultyHighscore(), GamePrefrences.GetMediumDifficultyCoinScore());
        }

        //hard
        if (GamePrefrences.GetHardDifficultyState() == 1)
        {
            SetScore(GamePrefrences.GetHardDifficultyHighscore(), GamePrefrences.GetHardDifficultyCoinScore());
        }

    }
	
	public void GoBackToMainMenu()
    {
        Application.LoadLevel("MainMenu");
    }

}
