﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {

    public static GameManager instance;

    [HideInInspector]
    public bool gameStartedFromMainMenu, gameRestartedAfterPlayerDied;


    [HideInInspector]
    public int score, coinScore, lifeScore;

	void Awake () {
        MakeSingleton();
	}

    void Start()
    {
        InitializeVariable();
    }
	
    void OnLevelWasLoaded()
    {
        if(Application.loadedLevelName == "Gameplay")
        {
            if (gameRestartedAfterPlayerDied){

                GameplayController.instance.SetScore(score);
                GameplayController.instance.SetScore(coinScore);
                GameplayController.instance.SetScore(lifeScore);

                PlayerScore.scoreCount = score;
                PlayerScore.coinCount = coinScore;
                PlayerScore.lifeCount = lifeScore;
            }


            else if(gameStartedFromMainMenu)
            {

                PlayerScore.scoreCount = 0;
                PlayerScore.coinCount = 0;
                PlayerScore.lifeCount = 2;

                GameplayController.instance.SetScore(0);
                GameplayController.instance.SetCoinScore(0);
                GameplayController.instance.SetLifeScore(2);

            }
        }
    }

    void InitializeVariable()
    {

        if (! PlayerPrefs.HasKey("Game Initialized"))
        {
            GamePrefrences.SetEasyDifficultyState(0);
            GamePrefrences.SetEasyDifficultyCoinScore(0);
            GamePrefrences.SetEasyDifficultyHighscore(0);

            GamePrefrences.SetMediumDifficultyState(1);
            GamePrefrences.SetMediumDifficultyCoinScore(0);
            GamePrefrences.SetMediumDifficultyHighscore(0);

            GamePrefrences.SetHardDifficultyState(0);
            GamePrefrences.SetHardDifficultyCoinScore(0);
            GamePrefrences.SetHardDifficultyHighscore(0);

            GamePrefrences.SetMusicState(0);

            PlayerPrefs.SetInt("Game Initialized", 123);


        }

    }

	void MakeSingleton () { 
   //Singleton it will not be destroyed after we restart the game or navigate b/w scns

        if(instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
	}

    public void CheckGameStatus(int score, int coinScore, int lifeScore)
    {
        if(lifeScore < 0)
        {

            //easy
            if(GamePrefrences.GetEasyDifficultyState() == 1)
            {
                int highScore = GamePrefrences.GetEasyDifficultyHighscore();
                int coinHighScore = GamePrefrences.GetEasyDifficultyCoinScore();


                if(highScore < score)
                    GamePrefrences.SetEasyDifficultyHighscore(score);

                if (coinHighScore < coinScore)
                    GamePrefrences.SetEasyDifficultyCoinScore(coinScore);

                
            }

            //medium
            if (GamePrefrences.GetMediumDifficultyState() == 1)
            {
                int highScore = GamePrefrences.GetMediumDifficultyHighscore();
                int coinHighScore = GamePrefrences.GetMediumDifficultyCoinScore();


                if (highScore < score)
                    GamePrefrences.SetMediumDifficultyHighscore(score);

                if (coinHighScore < coinScore)
                    GamePrefrences.SetMediumDifficultyCoinScore(coinScore);


            }

            //hard
            if (GamePrefrences.GetHardDifficultyState() == 1)
            {
                int highScore = GamePrefrences.GetHardDifficultyHighscore();
                int coinHighScore = GamePrefrences.GetHardDifficultyCoinScore();


                if (highScore < score)
                    GamePrefrences.SetHardDifficultyHighscore(score);

                if (coinHighScore < coinScore)
                    GamePrefrences.SetHardDifficultyCoinScore(coinScore);


            }

            gameStartedFromMainMenu = false;
            gameRestartedAfterPlayerDied = false;

            //GAMEPLAY CONTROLLER
            GameplayController.instance.GameOverShowPanel(score, coinScore);

        }
        else
        {
            this.score = score;
            this.coinScore = coinScore;
            this.lifeScore = lifeScore;

            gameRestartedAfterPlayerDied = true;
            gameStartedFromMainMenu = false;

            GameplayController.instance.PlayerDiedRestartTheGame();

        }
    }


}// Game Manager end
