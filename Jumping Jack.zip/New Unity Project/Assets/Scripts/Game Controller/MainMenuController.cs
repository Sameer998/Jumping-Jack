﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainMenuController : MonoBehaviour {

    [SerializeField]
    private Button musicBtn;

    [SerializeField]
    private Sprite[] musicIcons;

	// Use this for initialization
	void Start () {
        CheckToPlayTheMusic();

    }
	
     void CheckToPlayTheMusic()
    {
        if(GamePrefrences.GetMusicState () == 1)
        {
            MusicController.instance.PlayMusic(true);
            musicBtn.image.sprite = musicIcons[1];

        }
        else
        {
            MusicController.instance.PlayMusic(false);
            musicBtn.image.sprite = musicIcons[0];
        }
    }

	public void StartGame()
    {
        GameManager.instance.gameStartedFromMainMenu = true;
        //   Application.LoadLevel("Gameplay");
        SceneFader.instance.LoadLevel("Gameplay");
    }

    public void HighscoreMenu()
    {
        Application.LoadLevel("HighscoreScene");
    }

    public void OptionsMenu()
    {
        Application.LoadLevel("OptionsMenu");
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    public void MusicButton()
    {

        if(GamePrefrences.GetMusicState () == 0)
        {
            GamePrefrences.SetMusicState(1);
            MusicController.instance.PlayMusic(true);
            musicBtn.image.sprite = musicIcons[1];

        }
        else if(GamePrefrences.GetMusicState() == 1)
        {
            GamePrefrences.SetMusicState(0);
            MusicController.instance.PlayMusic(false);
            musicBtn.image.sprite = musicIcons[0];
        }

    }
}
