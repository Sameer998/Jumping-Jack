﻿using UnityEngine;
using System.Collections;

public static class GamePrefrences {

    public static string EasyDifficulty = "EasyDifficulty";
    public static string MediumDifficulty = "MediumDifficulty";
    public static string HardDifficulty = "HardDifficulty";

    public static string EasyDifficultyHighScore = "EasyDifficultyHighScore";
    public static string MediumDifficultyHighScore = "MediumDifficultyHighScore";
    public static string HardDifficultyHighScore = "HardDifficultyHighScore";

    public static string EasyDifficultyCoinScore = "EasyDifficultyScore";
    public static string MediumDifficultyCoinScore = "MediumDifficultyScore";
    public static string HardDifficultyCoinScore = "HardDifficultyScore";

    public static string IsMusicOn = "IsMusicOn";

    // Note: we are going to use interger to represent boolean variable
    // 0 = false   --   1 = true


        //Music
    public static int GetMusicState()
    {
        return PlayerPrefs.GetInt(GamePrefrences.IsMusicOn);
    }

    public static void SetMusicState(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.IsMusicOn, state); 
    }


    // easy difficulty
    public static int GetEasyDifficultyState()
    {
        return PlayerPrefs.GetInt(GamePrefrences.EasyDifficulty);  //get ma value dain gain hm
    }

    public static void SetEasyDifficultyState(int State)
    {
        PlayerPrefs.SetInt(GamePrefrences.EasyDifficulty, State); // phela key ha phir value ha difficulty value ha
    }


    //medium difficulty
    public static int GetMediumDifficultyState()
    {
        return PlayerPrefs.GetInt(GamePrefrences.MediumDifficulty);  
    }

    public static void SetMediumDifficultyState(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.MediumDifficulty, state); 
    }


    //hard difficuly

    public static int GetHardDifficultyState()
    {
        return PlayerPrefs.GetInt(GamePrefrences.HardDifficulty); 
    }

    public static void SetHardDifficultyState(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.HardDifficulty, state);
    }



    //method for easy difficulty high score
    public static int GetEasyDifficultyHighscore()
    {
        return PlayerPrefs.GetInt(GamePrefrences.EasyDifficultyHighScore);
    }

    public static void SetEasyDifficultyHighscore(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.EasyDifficultyHighScore, state);
    }


    //method for medium difficulty high score
    public static int GetMediumDifficultyHighscore()
    {
        return PlayerPrefs.GetInt(GamePrefrences.MediumDifficultyHighScore);
    }

    public static void SetMediumDifficultyHighscore(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.MediumDifficultyHighScore, state);
    }


    //method for hard difficulty high score
    public static int GetHardDifficultyHighscore()
    {
        return PlayerPrefs.GetInt(GamePrefrences.HardDifficultyHighScore);
    }

    public static void SetHardDifficultyHighscore(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.HardDifficultyHighScore, state);
    }


    //method for easy difficulty coin score
    public static int GetEasyDifficultyCoinScore()
    {
        return PlayerPrefs.GetInt(GamePrefrences.EasyDifficultyCoinScore);
    }

    public static void SetEasyDifficultyCoinScore(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.EasyDifficultyCoinScore, state);
    }


    //method for medium difficulty coin score
    public static int GetMediumDifficultyCoinScore()
    {
        return PlayerPrefs.GetInt(GamePrefrences.MediumDifficultyCoinScore);
    }

    public static void SetMediumDifficultyCoinScore(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.MediumDifficultyCoinScore, state);
    }


    //method for hard difficulty coin score
    public static int GetHardDifficultyCoinScore()
    {
        return PlayerPrefs.GetInt(GamePrefrences.HardDifficultyCoinScore);
    }

    public static void SetHardDifficultyCoinScore(int state)
    {
        PlayerPrefs.SetInt(GamePrefrences.HardDifficultyCoinScore, state);
    }

}//Game prefrences
