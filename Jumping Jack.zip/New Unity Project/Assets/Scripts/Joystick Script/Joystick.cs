﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class Joystick : MonoBehaviour, IPointerUpHandler, IPointerDownHandler {

    private PlayerJoystickMovement playerMove;

    void Start()
    {
        playerMove = GameObject.Find("Player").GetComponent<PlayerJoystickMovement>();
    }

    public void OnPointerDown(PointerEventData data)
    {

        if(gameObject.name == "Left")
        {
            playerMove.SetMoveLeft(true);
        }
        else
        {
            playerMove.SetMoveLeft(false);
        }

    }//when we touch a button

    public void OnPointerUp(PointerEventData data)
    {

        playerMove.StopMoving(); // when release a button stop moving

    } // when we release a button
	
	
}
